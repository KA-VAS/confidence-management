
  # Academic Conference Management UI

  This is a code bundle for Academic Conference Management UI. The original project is available at https://www.figma.com/design/FJXW2lE0l3Hbe0648kQlxf/Academic-Conference-Management-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  