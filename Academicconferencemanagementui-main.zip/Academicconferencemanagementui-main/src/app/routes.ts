import { createBrowserRouter } from "react-router";
import { Landing } from "./pages/Landing";
import { Login } from "./pages/Login";
import { Register } from "./pages/Register";
import { UserDashboard } from "./pages/UserDashboard";
import { AdminDashboard } from "./pages/AdminDashboard";
import { SubmitPaper } from "./pages/SubmitPaper";
import { ReviewManagement } from "./pages/ReviewManagement";
import { Schedule } from "./pages/Schedule";
import { Profile } from "./pages/Profile";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Landing,
  },
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/register",
    Component: Register,
  },
  {
    path: "/dashboard",
    Component: UserDashboard,
  },
  {
    path: "/admin",
    Component: AdminDashboard,
  },
  {
    path: "/submit-paper",
    Component: SubmitPaper,
  },
  {
    path: "/reviews",
    Component: ReviewManagement,
  },
  {
    path: "/schedule",
    Component: Schedule,
  },
  {
    path: "/profile",
    Component: Profile,
  },
]);
