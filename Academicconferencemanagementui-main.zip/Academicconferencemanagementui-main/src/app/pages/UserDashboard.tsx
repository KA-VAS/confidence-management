import { useState } from "react";
import { Link } from "react-router";
import { Navbar } from "../components/Navbar";
import { NotificationPanel } from "../components/NotificationPanel";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { 
  FileText, 
  Calendar, 
  CheckCircle, 
  Clock, 
  XCircle,
  TrendingUp,
  Send,
  Eye,
  BarChart,
  Plus
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";

export function UserDashboard() {
  const [notificationsPanelOpen, setNotificationsPanelOpen] = useState(false);

  // Mock data
  const submissions = [
    {
      id: 1,
      title: "Machine Learning Applications in Climate Science",
      status: "Under Review",
      submittedDate: "2026-01-15",
      reviewers: 3,
      conference: "ICML 2026"
    },
    {
      id: 2,
      title: "Quantum Computing: A New Era of Computation",
      status: "Accepted",
      submittedDate: "2026-01-05",
      reviewers: 3,
      conference: "QCS 2026"
    },
    {
      id: 3,
      title: "Neural Networks for Natural Language Processing",
      status: "Revision Requested",
      submittedDate: "2025-12-20",
      reviewers: 3,
      conference: "NLP Summit 2026"
    },
    {
      id: 4,
      title: "Blockchain Technology in Healthcare",
      status: "Rejected",
      submittedDate: "2025-12-10",
      reviewers: 3,
      conference: "HealthTech 2026"
    }
  ];

  const upcomingConferences = [
    {
      id: 1,
      name: "International Conference on Machine Learning",
      date: "March 15-18, 2026",
      location: "Vienna, Austria",
      registered: true
    },
    {
      id: 2,
      name: "Quantum Computing Symposium",
      date: "April 5-7, 2026",
      location: "Boston, USA",
      registered: true
    },
    {
      id: 3,
      name: "NLP Summit 2026",
      date: "May 22-25, 2026",
      location: "London, UK",
      registered: false
    }
  ];

  const stats = [
    { label: "Total Submissions", value: 4, icon: FileText, color: "text-blue-600" },
    { label: "Accepted", value: 1, icon: CheckCircle, color: "text-green-600" },
    { label: "Under Review", value: 1, icon: Clock, color: "text-yellow-600" },
    { label: "Conferences Registered", value: 2, icon: Calendar, color: "text-purple-600" }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Accepted": return "bg-green-100 text-green-700 border-green-200";
      case "Under Review": return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "Rejected": return "bg-red-100 text-red-700 border-red-200";
      case "Revision Requested": return "bg-orange-100 text-orange-700 border-orange-200";
      default: return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Accepted": return <CheckCircle className="h-4 w-4" />;
      case "Under Review": return <Clock className="h-4 w-4" />;
      case "Rejected": return <XCircle className="h-4 w-4" />;
      case "Revision Requested": return <Send className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background">
      <Navbar 
        isAuthenticated={true}
        userRole="user"
        userName="Dr. Jane Smith"
        notificationCount={3}
        onNotificationsClick={() => setNotificationsPanelOpen(true)}
      />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back! Here's an overview of your submissions and conferences.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="border-2 hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <div className={`h-10 w-10 rounded-lg bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center ${stat.color}`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="text-2xl font-bold mb-1">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - Submissions */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-2">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                <div>
                  <CardTitle>Paper Submissions</CardTitle>
                  <CardDescription>Track your submitted papers and their review status</CardDescription>
                </div>
                <Link to="/submit-paper">
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Submit Paper
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all" className="w-full">
                  <TabsList className="w-full grid grid-cols-4 mb-4">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="review">Review</TabsTrigger>
                    <TabsTrigger value="accepted">Accepted</TabsTrigger>
                    <TabsTrigger value="revision">Revision</TabsTrigger>
                  </TabsList>

                  <TabsContent value="all" className="space-y-4">
                    {submissions.map((submission) => (
                      <Card key={submission.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <h3 className="font-semibold mb-1">{submission.title}</h3>
                              <p className="text-sm text-muted-foreground">{submission.conference}</p>
                            </div>
                            <Badge className={`${getStatusColor(submission.status)} border flex items-center gap-1`}>
                              {getStatusIcon(submission.status)}
                              {submission.status}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <div className="text-muted-foreground">
                              Submitted: {new Date(submission.submittedDate).toLocaleDateString()}
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-muted-foreground">{submission.reviewers} reviewers</span>
                              <Button variant="ghost" size="sm">
                                <Eye className="h-4 w-4 mr-1" />
                                View
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>

                  <TabsContent value="review" className="space-y-4">
                    {submissions.filter(s => s.status === "Under Review").map((submission) => (
                      <Card key={submission.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <h3 className="font-semibold mb-1">{submission.title}</h3>
                              <p className="text-sm text-muted-foreground">{submission.conference}</p>
                            </div>
                            <Badge className={`${getStatusColor(submission.status)} border flex items-center gap-1`}>
                              {getStatusIcon(submission.status)}
                              {submission.status}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <div className="text-muted-foreground">
                              Submitted: {new Date(submission.submittedDate).toLocaleDateString()}
                            </div>
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>

                  <TabsContent value="accepted" className="space-y-4">
                    {submissions.filter(s => s.status === "Accepted").map((submission) => (
                      <Card key={submission.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <h3 className="font-semibold mb-1">{submission.title}</h3>
                              <p className="text-sm text-muted-foreground">{submission.conference}</p>
                            </div>
                            <Badge className={`${getStatusColor(submission.status)} border flex items-center gap-1`}>
                              {getStatusIcon(submission.status)}
                              {submission.status}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <div className="text-muted-foreground">
                              Submitted: {new Date(submission.submittedDate).toLocaleDateString()}
                            </div>
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>

                  <TabsContent value="revision" className="space-y-4">
                    {submissions.filter(s => s.status === "Revision Requested").map((submission) => (
                      <Card key={submission.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <h3 className="font-semibold mb-1">{submission.title}</h3>
                              <p className="text-sm text-muted-foreground">{submission.conference}</p>
                            </div>
                            <Badge className={`${getStatusColor(submission.status)} border flex items-center gap-1`}>
                              {getStatusIcon(submission.status)}
                              {submission.status}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <div className="text-muted-foreground">
                              Submitted: {new Date(submission.submittedDate).toLocaleDateString()}
                            </div>
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Conferences & Quick Actions */}
          <div className="space-y-6">
            {/* Upcoming Conferences */}
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Upcoming Conferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {upcomingConferences.map((conference) => (
                  <div key={conference.id} className="p-4 rounded-lg border bg-card hover:shadow-md transition-shadow">
                    <h4 className="font-semibold mb-2">{conference.name}</h4>
                    <p className="text-sm text-muted-foreground mb-1">{conference.date}</p>
                    <p className="text-sm text-muted-foreground mb-3">{conference.location}</p>
                    {conference.registered ? (
                      <Badge variant="secondary" className="bg-green-100 text-green-700">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Registered
                      </Badge>
                    ) : (
                      <Button variant="outline" size="sm" className="w-full">
                        Register Now
                      </Button>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link to="/submit-paper" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="mr-2 h-4 w-4" />
                    Submit New Paper
                  </Button>
                </Link>
                <Link to="/schedule" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <Calendar className="mr-2 h-4 w-4" />
                    View Schedule
                  </Button>
                </Link>
                <Link to="/profile" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <BarChart className="mr-2 h-4 w-4" />
                    View Profile
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <NotificationPanel 
        isOpen={notificationsPanelOpen}
        onClose={() => setNotificationsPanelOpen(false)}
      />
    </div>
  );
}
