import { useState } from "react";
import { Link } from "react-router";
import { Navbar } from "../components/Navbar";
import { NotificationPanel } from "../components/NotificationPanel";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { 
  Search,
  Filter,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  FileText,
  User,
  Calendar,
  Download,
  MessageSquare
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import { Label } from "../components/ui/label";

export function ReviewManagement() {
  const [notificationsPanelOpen, setNotificationsPanelOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPaper, setSelectedPaper] = useState<any>(null);

  // Mock data
  const papers = [
    {
      id: 1,
      title: "Deep Learning for Medical Image Analysis",
      author: "Dr. Sarah Johnson",
      submittedDate: "2026-02-20",
      status: "Under Review",
      reviewers: [
        { name: "Dr. Robert Brown", status: "Completed", score: 8, recommendation: "Accept" },
        { name: "Prof. Maria Garcia", status: "Completed", score: 9, recommendation: "Accept" },
        { name: "Dr. David Lee", status: "In Progress", score: null, recommendation: null }
      ],
      category: "Machine Learning",
      abstract: "This paper presents a novel approach to medical image analysis using deep learning techniques..."
    },
    {
      id: 2,
      title: "Blockchain Applications in Supply Chain",
      author: "Prof. Michael Chen",
      submittedDate: "2026-02-19",
      status: "Pending Assignment",
      reviewers: [],
      category: "Blockchain",
      abstract: "We explore practical applications of blockchain technology in modern supply chain management..."
    },
    {
      id: 3,
      title: "AI-Powered Climate Modeling",
      author: "Dr. Emma Wilson",
      submittedDate: "2026-02-18",
      status: "Under Review",
      reviewers: [
        { name: "Dr. Lisa Anderson", status: "Completed", score: 7, recommendation: "Minor Revision" },
        { name: "Prof. James Taylor", status: "In Progress", score: null, recommendation: null }
      ],
      category: "AI",
      abstract: "This research investigates the use of artificial intelligence in climate prediction models..."
    },
    {
      id: 4,
      title: "Quantum Cryptography Advances",
      author: "Dr. James Rodriguez",
      submittedDate: "2026-02-17",
      status: "Reviewed",
      reviewers: [
        { name: "Dr. Susan White", status: "Completed", score: 9, recommendation: "Accept" },
        { name: "Prof. David Kim", status: "Completed", score: 8, recommendation: "Accept" },
        { name: "Dr. Anna Lee", status: "Completed", score: 9, recommendation: "Accept" }
      ],
      category: "Security",
      abstract: "We present significant advances in quantum cryptography protocols and their implementation..."
    },
    {
      id: 5,
      title: "Neural Architecture Search Methods",
      author: "Dr. Lisa Anderson",
      submittedDate: "2026-02-16",
      status: "Under Review",
      reviewers: [
        { name: "Prof. Robert Chen", status: "Completed", score: 6, recommendation: "Major Revision" },
        { name: "Dr. Maria Lopez", status: "Completed", score: 7, recommendation: "Minor Revision" },
        { name: "Dr. John Smith", status: "In Progress", score: null, recommendation: null }
      ],
      category: "Machine Learning",
      abstract: "This paper explores automated neural architecture search techniques for optimizing deep learning models..."
    }
  ];

  const availableReviewers = [
    { id: 1, name: "Dr. Robert Brown", expertise: "Machine Learning", available: true },
    { id: 2, name: "Prof. Maria Garcia", expertise: "Computer Vision", available: true },
    { id: 3, name: "Dr. David Lee", expertise: "NLP", available: false },
    { id: 4, name: "Dr. Susan Taylor", expertise: "Robotics", available: true },
    { id: 5, name: "Prof. James Wilson", expertise: "AI", available: true },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Under Review": return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "Pending Assignment": return "bg-blue-100 text-blue-700 border-blue-200";
      case "Reviewed": return "bg-green-100 text-green-700 border-green-200";
      case "Rejected": return "bg-red-100 text-red-700 border-red-200";
      default: return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Under Review": return <Clock className="h-3 w-3" />;
      case "Pending Assignment": return <AlertCircle className="h-3 w-3" />;
      case "Reviewed": return <CheckCircle className="h-3 w-3" />;
      case "Rejected": return <XCircle className="h-3 w-3" />;
      default: return <FileText className="h-3 w-3" />;
    }
  };

  const getRecommendationColor = (recommendation: string) => {
    switch (recommendation) {
      case "Accept": return "text-green-700";
      case "Minor Revision": return "text-yellow-700";
      case "Major Revision": return "text-orange-700";
      case "Reject": return "text-red-700";
      default: return "text-gray-700";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background">
      <Navbar 
        isAuthenticated={true}
        userRole="admin"
        userName="Admin User"
        notificationCount={5}
        onNotificationsClick={() => setNotificationsPanelOpen(true)}
      />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Review Management</h1>
          <p className="text-muted-foreground">Manage paper submissions, assign reviewers, and track review progress</p>
        </div>

        {/* Search and Filter */}
        <Card className="border-2 mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search papers by title, author, or keyword..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select>
                <SelectTrigger className="md:w-48">
                  <Filter className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Papers</SelectItem>
                  <SelectItem value="pending">Pending Assignment</SelectItem>
                  <SelectItem value="review">Under Review</SelectItem>
                  <SelectItem value="reviewed">Reviewed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Papers List */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid grid-cols-4 w-full max-w-2xl mb-6">
            <TabsTrigger value="all">All Papers</TabsTrigger>
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="review">In Review</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {papers.map((paper) => (
              <Card key={paper.id} className="border-2 hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold">{paper.title}</h3>
                        <Badge className={`${getStatusColor(paper.status)} border flex items-center gap-1`}>
                          {getStatusIcon(paper.status)}
                          {paper.status}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                        <span className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          {paper.author}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {new Date(paper.submittedDate).toLocaleDateString()}
                        </span>
                        <Badge variant="outline">{paper.category}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2">{paper.abstract}</p>
                    </div>
                  </div>

                  {/* Reviewer Status */}
                  <div className="border-t pt-4 mt-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-semibold">Reviewers ({paper.reviewers.length}/3)</h4>
                      {paper.reviewers.length < 3 && (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="outline">
                              <User className="mr-2 h-4 w-4" />
                              Assign Reviewer
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Assign Reviewer</DialogTitle>
                              <DialogDescription>
                                Select a reviewer to assign to this paper
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-3">
                              {availableReviewers.map((reviewer) => (
                                <div 
                                  key={reviewer.id} 
                                  className="flex items-center justify-between p-3 rounded-lg border hover:bg-secondary cursor-pointer"
                                >
                                  <div>
                                    <p className="font-medium">{reviewer.name}</p>
                                    <p className="text-sm text-muted-foreground">{reviewer.expertise}</p>
                                  </div>
                                  <Button size="sm" disabled={!reviewer.available}>
                                    {reviewer.available ? "Assign" : "Unavailable"}
                                  </Button>
                                </div>
                              ))}
                            </div>
                          </DialogContent>
                        </Dialog>
                      )}
                    </div>

                    {paper.reviewers.length > 0 ? (
                      <div className="grid md:grid-cols-3 gap-3">
                        {paper.reviewers.map((reviewer, idx) => (
                          <div key={idx} className="p-3 rounded-lg border bg-card">
                            <div className="flex items-center justify-between mb-2">
                              <p className="text-sm font-medium">{reviewer.name}</p>
                              {reviewer.status === "Completed" ? (
                                <CheckCircle className="h-4 w-4 text-green-600" />
                              ) : (
                                <Clock className="h-4 w-4 text-yellow-600" />
                              )}
                            </div>
                            {reviewer.status === "Completed" ? (
                              <div className="space-y-1">
                                <div className="flex items-center justify-between text-xs">
                                  <span className="text-muted-foreground">Score:</span>
                                  <span className="font-semibold">{reviewer.score}/10</span>
                                </div>
                                <div className="flex items-center justify-between text-xs">
                                  <span className="text-muted-foreground">Decision:</span>
                                  <span className={`font-semibold ${getRecommendationColor(reviewer.recommendation || '')}`}>
                                    {reviewer.recommendation}
                                  </span>
                                </div>
                              </div>
                            ) : (
                              <p className="text-xs text-muted-foreground">Review in progress...</p>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-6 border rounded-lg bg-muted/50">
                        <AlertCircle className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                        <p className="text-sm text-muted-foreground">No reviewers assigned yet</p>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 mt-4 pt-4 border-t">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <FileText className="mr-2 h-4 w-4" />
                          View Details
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>{paper.title}</DialogTitle>
                          <DialogDescription>by {paper.author}</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label>Abstract</Label>
                            <p className="text-sm text-muted-foreground mt-1">{paper.abstract}</p>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label>Category</Label>
                              <p className="text-sm mt-1">{paper.category}</p>
                            </div>
                            <div>
                              <Label>Submitted</Label>
                              <p className="text-sm mt-1">{new Date(paper.submittedDate).toLocaleDateString()}</p>
                            </div>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Download PDF
                    </Button>
                    <Button variant="outline" size="sm">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Contact Author
                    </Button>
                    {paper.status === "Reviewed" && (
                      <>
                        <Button size="sm" variant="default" className="ml-auto">
                          <CheckCircle className="mr-2 h-4 w-4" />
                          Accept
                        </Button>
                        <Button size="sm" variant="destructive">
                          <XCircle className="mr-2 h-4 w-4" />
                          Reject
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="pending" className="space-y-4">
            {papers.filter(p => p.status === "Pending Assignment").map((paper) => (
              <Card key={paper.id} className="border-2">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-2">{paper.title}</h3>
                      <p className="text-sm text-muted-foreground mb-4">{paper.abstract}</p>
                      <Badge className={`${getStatusColor(paper.status)} border`}>
                        {getStatusIcon(paper.status)}
                        {paper.status}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="review" className="space-y-4">
            {papers.filter(p => p.status === "Under Review").map((paper) => (
              <Card key={paper.id} className="border-2">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-2">{paper.title}</h3>
                  <p className="text-sm text-muted-foreground">{paper.abstract}</p>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="completed" className="space-y-4">
            {papers.filter(p => p.status === "Reviewed").map((paper) => (
              <Card key={paper.id} className="border-2">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-2">{paper.title}</h3>
                  <p className="text-sm text-muted-foreground">{paper.abstract}</p>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>

      <NotificationPanel 
        isOpen={notificationsPanelOpen}
        onClose={() => setNotificationsPanelOpen(false)}
      />
    </div>
  );
}
