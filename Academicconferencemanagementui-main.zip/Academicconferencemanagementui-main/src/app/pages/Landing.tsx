import { Link } from "react-router";
import { Navbar } from "../components/Navbar";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { 
  FileText, 
  Users, 
  Calendar, 
  Award, 
  TrendingUp, 
  CheckCircle,
  ArrowRight,
  BookOpen,
  Globe,
  Zap
} from "lucide-react";

export function Landing() {
  const features = [
    {
      icon: FileText,
      title: "Paper Submissions",
      description: "Submit and manage conference papers with ease. Track submission status in real-time."
    },
    {
      icon: Users,
      title: "Peer Review System",
      description: "Efficient peer review management with automated reviewer assignments and tracking."
    },
    {
      icon: Calendar,
      title: "Conference Scheduling",
      description: "Organize sessions, speakers, and presentations with an intuitive schedule builder."
    },
    {
      icon: Award,
      title: "Registration Management",
      description: "Seamless attendee registration and badge generation for conference participants."
    },
    {
      icon: TrendingUp,
      title: "Analytics & Reports",
      description: "Comprehensive analytics dashboard to monitor submissions and engagement metrics."
    },
    {
      icon: Globe,
      title: "Global Collaboration",
      description: "Connect researchers and academics from around the world on one platform."
    }
  ];

  const stats = [
    { value: "10K+", label: "Papers Submitted" },
    { value: "500+", label: "Conferences Hosted" },
    { value: "50K+", label: "Active Researchers" },
    { value: "95%", label: "Satisfaction Rate" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-primary/20 mb-6">
            <Zap className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-secondary-foreground">
              The Future of Academic Conference Management
            </span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
            Streamline Your Academic Conference Experience
          </h1>
          
          <p className="text-lg sm:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
            A comprehensive platform for managing paper submissions, peer reviews, conference schedules, 
            and attendee registrations—all in one place.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" className="w-full sm:w-auto text-lg px-8 shadow-lg hover:shadow-xl transition-shadow">
                <FileText className="mr-2 h-5 w-5" />
                Submit Paper
              </Button>
            </Link>
            <Link to="/register">
              <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg px-8 border-2">
                <Users className="mr-2 h-5 w-5" />
                Register Now
              </Button>
            </Link>
          </div>

          {/* Trust Indicators */}
          <div className="mt-12 flex flex-wrap justify-center gap-8 text-sm text-muted-foreground">
            {['MIT', 'Stanford', 'Oxford', 'Cambridge'].map((uni) => (
              <div key={uni} className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-primary" />
                <span>Trusted by {uni}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {stats.map((stat, index) => (
            <Card key={index} className="text-center border-2 shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="text-3xl sm:text-4xl font-bold text-primary mb-2">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Everything You Need to Run a Successful Conference
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Powerful features designed for researchers, reviewers, and conference organizers
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card 
                key={index} 
                className="group hover:shadow-lg hover:border-primary/40 transition-all duration-300 hover:-translate-y-1"
              >
                <CardHeader>
                  <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            );
          })}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <Card className="max-w-4xl mx-auto bg-gradient-to-r from-primary to-accent text-white border-0 shadow-2xl overflow-hidden">
          <CardContent className="p-12">
            <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
              <div className="text-center lg:text-left">
                <h2 className="text-3xl font-bold mb-4">
                  Ready to Get Started?
                </h2>
                <p className="text-lg opacity-90 max-w-md">
                  Join thousands of researchers and academics already using our platform
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/register">
                  <Button 
                    size="lg" 
                    variant="secondary" 
                    className="w-full sm:w-auto shadow-lg hover:shadow-xl transition-shadow"
                  >
                    Create Account
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link to="/schedule">
                  <Button 
                    size="lg" 
                    variant="outline" 
                    className="w-full sm:w-auto border-2 border-white text-white hover:bg-white/10"
                  >
                    <BookOpen className="mr-2 h-5 w-5" />
                    View Schedule
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2026 AcademicConf. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
