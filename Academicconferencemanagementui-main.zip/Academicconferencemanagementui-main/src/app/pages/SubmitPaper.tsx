import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { Navbar } from "../components/Navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { FileText, Upload, X, CheckCircle } from "lucide-react";
import { Badge } from "../components/ui/badge";

export function SubmitPaper() {
  const navigate = useNavigate();
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    abstract: "",
    keywords: "",
    conference: "",
    primaryAuthor: "",
    primaryEmail: "",
    primaryAffiliation: "",
    coAuthors: "",
    category: "",
    format: ""
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const handleRemoveFile = () => {
    setUploadedFile(null);
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock submission - redirect to dashboard
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background">
      <Navbar isAuthenticated={true} userRole="user" userName="Dr. Jane Smith" />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link to="/dashboard">
            <Button variant="ghost" size="sm" className="mb-4">
              ← Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold mb-2">Submit Paper</h1>
          <p className="text-muted-foreground">Submit your research paper for conference review</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Paper Submission Form
              </CardTitle>
              <CardDescription>
                Please fill out all required fields and upload your paper in PDF format
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Paper Details Section */}
                <div className="space-y-4">
                  <div className="pb-2 border-b">
                    <h3 className="font-semibold">Paper Details</h3>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="title">Paper Title *</Label>
                    <Input
                      id="title"
                      placeholder="Enter the title of your paper"
                      value={formData.title}
                      onChange={(e) => handleChange('title', e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="abstract">Abstract *</Label>
                    <Textarea
                      id="abstract"
                      placeholder="Provide a brief abstract of your paper (max 300 words)"
                      rows={6}
                      value={formData.abstract}
                      onChange={(e) => handleChange('abstract', e.target.value)}
                      required
                    />
                    <p className="text-xs text-muted-foreground">
                      {formData.abstract.split(' ').filter(w => w).length} / 300 words
                    </p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="keywords">Keywords *</Label>
                      <Input
                        id="keywords"
                        placeholder="machine learning, AI, neural networks"
                        value={formData.keywords}
                        onChange={(e) => handleChange('keywords', e.target.value)}
                        required
                      />
                      <p className="text-xs text-muted-foreground">Separate keywords with commas</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="category">Research Category *</Label>
                      <Select value={formData.category} onValueChange={(value) => handleChange('category', value)}>
                        <SelectTrigger id="category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ai">Artificial Intelligence</SelectItem>
                          <SelectItem value="ml">Machine Learning</SelectItem>
                          <SelectItem value="cv">Computer Vision</SelectItem>
                          <SelectItem value="nlp">Natural Language Processing</SelectItem>
                          <SelectItem value="robotics">Robotics</SelectItem>
                          <SelectItem value="security">Security & Privacy</SelectItem>
                          <SelectItem value="systems">Systems & Networks</SelectItem>
                          <SelectItem value="theory">Theory</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="conference">Target Conference *</Label>
                      <Select value={formData.conference} onValueChange={(value) => handleChange('conference', value)}>
                        <SelectTrigger id="conference">
                          <SelectValue placeholder="Select conference" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="icml2026">ICML 2026</SelectItem>
                          <SelectItem value="qcs2026">QCS 2026</SelectItem>
                          <SelectItem value="nlp2026">NLP Summit 2026</SelectItem>
                          <SelectItem value="healthtech2026">HealthTech 2026</SelectItem>
                          <SelectItem value="ai-conf2026">AI Conference 2026</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="format">Paper Format *</Label>
                      <Select value={formData.format} onValueChange={(value) => handleChange('format', value)}>
                        <SelectTrigger id="format">
                          <SelectValue placeholder="Select format" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="full">Full Paper (8-10 pages)</SelectItem>
                          <SelectItem value="short">Short Paper (4-6 pages)</SelectItem>
                          <SelectItem value="poster">Poster Abstract (2 pages)</SelectItem>
                          <SelectItem value="workshop">Workshop Paper (6 pages)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Author Details Section */}
                <div className="space-y-4">
                  <div className="pb-2 border-b">
                    <h3 className="font-semibold">Author Information</h3>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="primaryAuthor">Primary Author Name *</Label>
                    <Input
                      id="primaryAuthor"
                      placeholder="Dr. Jane Smith"
                      value={formData.primaryAuthor}
                      onChange={(e) => handleChange('primaryAuthor', e.target.value)}
                      required
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="primaryEmail">Primary Author Email *</Label>
                      <Input
                        id="primaryEmail"
                        type="email"
                        placeholder="jane.smith@university.edu"
                        value={formData.primaryEmail}
                        onChange={(e) => handleChange('primaryEmail', e.target.value)}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="primaryAffiliation">Affiliation *</Label>
                      <Input
                        id="primaryAffiliation"
                        placeholder="University Name, Department"
                        value={formData.primaryAffiliation}
                        onChange={(e) => handleChange('primaryAffiliation', e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="coAuthors">Co-Authors (Optional)</Label>
                    <Textarea
                      id="coAuthors"
                      placeholder="List co-authors with their affiliations, one per line"
                      rows={3}
                      value={formData.coAuthors}
                      onChange={(e) => handleChange('coAuthors', e.target.value)}
                    />
                  </div>
                </div>

                {/* File Upload Section */}
                <div className="space-y-4">
                  <div className="pb-2 border-b">
                    <h3 className="font-semibold">Paper Upload</h3>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="file">Upload Paper (PDF) *</Label>
                    <div className="border-2 border-dashed rounded-lg p-8 text-center hover:border-primary transition-colors">
                      {uploadedFile ? (
                        <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                              <FileText className="h-5 w-5 text-primary" />
                            </div>
                            <div className="text-left">
                              <p className="font-medium">{uploadedFile.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                              </p>
                            </div>
                          </div>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={handleRemoveFile}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <>
                          <Upload className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                          <p className="text-sm text-muted-foreground mb-4">
                            Drag and drop your PDF file here, or click to browse
                          </p>
                          <Input
                            id="file"
                            type="file"
                            accept=".pdf"
                            onChange={handleFileUpload}
                            className="hidden"
                          />
                          <label htmlFor="file">
                            <Button type="button" variant="outline" asChild>
                              <span>Choose File</span>
                            </Button>
                          </label>
                          <p className="text-xs text-muted-foreground mt-4">
                            Maximum file size: 10 MB • Accepted format: PDF only
                          </p>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Guidelines */}
                <Card className="bg-blue-50 border-blue-200">
                  <CardContent className="p-4">
                    <div className="flex gap-3">
                      <CheckCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
                      <div className="text-sm space-y-1">
                        <p className="font-semibold text-blue-900">Submission Guidelines</p>
                        <ul className="text-blue-800 space-y-1">
                          <li>• Papers must be original and not published elsewhere</li>
                          <li>• Follow the conference formatting guidelines</li>
                          <li>• Ensure all authors have approved the submission</li>
                          <li>• Review process typically takes 4-6 weeks</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Submit Buttons */}
                <div className="flex gap-4 pt-4">
                  <Button type="submit" className="flex-1" size="lg">
                    <FileText className="mr-2 h-5 w-5" />
                    Submit Paper
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="lg"
                    onClick={() => navigate('/dashboard')}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
