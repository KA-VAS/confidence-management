import { useState } from "react";
import { Link } from "react-router";
import { Navbar } from "../components/Navbar";
import { NotificationPanel } from "../components/NotificationPanel";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Badge } from "../components/ui/badge";
import { 
  User,
  Mail,
  Building,
  BookOpen,
  Award,
  Settings,
  FileText,
  Calendar,
  TrendingUp,
  Edit,
  Save
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Progress } from "../components/ui/progress";

export function Profile() {
  const [notificationsPanelOpen, setNotificationsPanelOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    name: "Dr. Jane Smith",
    email: "jane.smith@university.edu",
    institution: "Stanford University",
    department: "Computer Science",
    position: "Associate Professor",
    researchInterests: "Machine Learning, Computer Vision, AI Ethics",
    bio: "Dr. Jane Smith is an Associate Professor specializing in machine learning and computer vision with over 10 years of research experience.",
    orcid: "0000-0002-1234-5678",
    website: "https://janesmith.edu"
  });

  // Mock data
  const stats = [
    { label: "Papers Submitted", value: 12, icon: FileText },
    { label: "Papers Accepted", value: 8, icon: Award },
    { label: "Conferences Attended", value: 15, icon: Calendar },
    { label: "Citations", value: 324, icon: TrendingUp }
  ];

  const publications = [
    {
      title: "Deep Learning Applications in Medical Imaging",
      conference: "ICML 2025",
      status: "Published",
      year: 2025
    },
    {
      title: "Ethical Considerations in AI Systems",
      conference: "AI Ethics Summit 2024",
      status: "Published",
      year: 2024
    },
    {
      title: "Neural Architecture Search Optimization",
      conference: "NeurIPS 2024",
      status: "Published",
      year: 2024
    }
  ];

  const upcomingConferences = [
    {
      name: "ICML 2026",
      date: "March 15-18, 2026",
      role: "Speaker",
      status: "Registered"
    },
    {
      name: "QCS 2026",
      date: "April 5-7, 2026",
      role: "Attendee",
      status: "Registered"
    }
  ];

  const handleSave = () => {
    setIsEditing(false);
    // Mock save - in real app would save to backend
  };

  const handleChange = (field: string, value: string) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background">
      <Navbar 
        isAuthenticated={true}
        userRole="user"
        userName="Dr. Jane Smith"
        notificationCount={3}
        onNotificationsClick={() => setNotificationsPanelOpen(true)}
      />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Profile</h1>
            <p className="text-muted-foreground">Manage your profile and view your academic activity</p>
          </div>
          <div className="flex gap-2">
            {isEditing ? (
              <>
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </Button>
              </>
            ) : (
              <Button onClick={() => setIsEditing(true)}>
                <Edit className="mr-2 h-4 w-4" />
                Edit Profile
              </Button>
            )}
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - Profile Card */}
          <div className="space-y-6">
            <Card className="border-2">
              <CardContent className="pt-6">
                <div className="text-center mb-6">
                  <div className="h-24 w-24 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center mx-auto mb-4">
                    <User className="h-12 w-12 text-white" />
                  </div>
                  <h2 className="text-xl font-bold mb-1">{profileData.name}</h2>
                  <p className="text-sm text-muted-foreground mb-1">{profileData.position}</p>
                  <p className="text-sm text-muted-foreground">{profileData.institution}</p>
                </div>

                <div className="space-y-3 border-t pt-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{profileData.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Building className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{profileData.department}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <BookOpen className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">ORCID: {profileData.orcid}</span>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t">
                  <p className="text-sm font-semibold mb-2">Research Interests</p>
                  <div className="flex flex-wrap gap-2">
                    {profileData.researchInterests.split(', ').map((interest, idx) => (
                      <Badge key={idx} variant="secondary">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Stats */}
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Statistics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {stats.map((stat, idx) => {
                  const Icon = stat.icon;
                  return (
                    <div key={idx} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Icon className="h-4 w-4 text-primary" />
                        </div>
                        <span className="text-sm text-muted-foreground">{stat.label}</span>
                      </div>
                      <span className="font-semibold">{stat.value}</span>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Details */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="details" className="w-full">
              <TabsList className="grid grid-cols-3 w-full max-w-xl">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="publications">Publications</TabsTrigger>
                <TabsTrigger value="conferences">Conferences</TabsTrigger>
              </TabsList>

              <TabsContent value="details" className="space-y-6">
                <Card className="border-2">
                  <CardHeader>
                    <CardTitle>Personal Information</CardTitle>
                    <CardDescription>Your basic profile information</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={profileData.name}
                          onChange={(e) => handleChange('name', e.target.value)}
                          disabled={!isEditing}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={profileData.email}
                          onChange={(e) => handleChange('email', e.target.value)}
                          disabled={!isEditing}
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="institution">Institution</Label>
                        <Input
                          id="institution"
                          value={profileData.institution}
                          onChange={(e) => handleChange('institution', e.target.value)}
                          disabled={!isEditing}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="department">Department</Label>
                        <Input
                          id="department"
                          value={profileData.department}
                          onChange={(e) => handleChange('department', e.target.value)}
                          disabled={!isEditing}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="position">Position</Label>
                      <Input
                        id="position"
                        value={profileData.position}
                        onChange={(e) => handleChange('position', e.target.value)}
                        disabled={!isEditing}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        rows={4}
                        value={profileData.bio}
                        onChange={(e) => handleChange('bio', e.target.value)}
                        disabled={!isEditing}
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="orcid">ORCID</Label>
                        <Input
                          id="orcid"
                          value={profileData.orcid}
                          onChange={(e) => handleChange('orcid', e.target.value)}
                          disabled={!isEditing}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="website">Website</Label>
                        <Input
                          id="website"
                          type="url"
                          value={profileData.website}
                          onChange={(e) => handleChange('website', e.target.value)}
                          disabled={!isEditing}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2">
                  <CardHeader>
                    <CardTitle>Research Interests</CardTitle>
                    <CardDescription>Areas of expertise and research focus</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Label htmlFor="interests">Research Areas (comma-separated)</Label>
                      <Textarea
                        id="interests"
                        rows={3}
                        value={profileData.researchInterests}
                        onChange={(e) => handleChange('researchInterests', e.target.value)}
                        disabled={!isEditing}
                        placeholder="Machine Learning, Computer Vision, AI Ethics"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="publications" className="space-y-4">
                <Card className="border-2">
                  <CardHeader>
                    <CardTitle>Publications</CardTitle>
                    <CardDescription>Your published papers and research</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {publications.map((pub, idx) => (
                      <Card key={idx} className="border">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <h4 className="font-semibold mb-1">{pub.title}</h4>
                              <p className="text-sm text-muted-foreground">
                                {pub.conference} • {pub.year}
                              </p>
                            </div>
                            <Badge variant="secondary" className="bg-green-100 text-green-700">
                              {pub.status}
                            </Badge>
                          </div>
                          <div className="flex gap-2 mt-3">
                            <Button variant="outline" size="sm">
                              <FileText className="mr-2 h-3 w-3" />
                              View
                            </Button>
                            <Button variant="outline" size="sm">
                              Download
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </CardContent>
                </Card>

                {/* Publication Stats */}
                <Card className="border-2">
                  <CardHeader>
                    <CardTitle>Publication Metrics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm">Acceptance Rate</span>
                        <span className="text-sm font-semibold">67%</span>
                      </div>
                      <Progress value={67} className="h-2" />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm">Citation Impact</span>
                        <span className="text-sm font-semibold">324 citations</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm">H-Index</span>
                        <span className="text-sm font-semibold">12</span>
                      </div>
                      <Progress value={60} className="h-2" />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="conferences" className="space-y-4">
                <Card className="border-2">
                  <CardHeader>
                    <CardTitle>Upcoming Conferences</CardTitle>
                    <CardDescription>Conferences you're registered for</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {upcomingConferences.map((conf, idx) => (
                      <Card key={idx} className="border">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <h4 className="font-semibold mb-1">{conf.name}</h4>
                              <p className="text-sm text-muted-foreground mb-2">{conf.date}</p>
                              <div className="flex gap-2">
                                <Badge variant="outline">{conf.role}</Badge>
                                <Badge variant="secondary" className="bg-green-100 text-green-700">
                                  {conf.status}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2 mt-3">
                            <Link to="/schedule">
                              <Button variant="outline" size="sm">
                                <Calendar className="mr-2 h-3 w-3" />
                                View Schedule
                              </Button>
                            </Link>
                            <Button variant="outline" size="sm">
                              Download Badge
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </CardContent>
                </Card>

                {/* Conference History */}
                <Card className="border-2">
                  <CardHeader>
                    <CardTitle>Conference History</CardTitle>
                    <CardDescription>Past conferences attended</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {['ICML 2025', 'NeurIPS 2024', 'CVPR 2024', 'ICCV 2023'].map((conf, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 rounded-lg border">
                          <span className="font-medium">{conf}</span>
                          <Badge variant="outline">Attended</Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>

      <NotificationPanel 
        isOpen={notificationsPanelOpen}
        onClose={() => setNotificationsPanelOpen(false)}
      />
    </div>
  );
}
