import { useState } from "react";
import { Link } from "react-router";
import { Navbar } from "../components/Navbar";
import { NotificationPanel } from "../components/NotificationPanel";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { 
  Users, 
  FileText, 
  Calendar,
  TrendingUp,
  CheckCircle,
  Clock,
  XCircle,
  AlertCircle,
  UserCheck,
  Settings,
  Download
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Progress } from "../components/ui/progress";

export function AdminDashboard() {
  const [notificationsPanelOpen, setNotificationsPanelOpen] = useState(false);

  // Mock data
  const stats = [
    { label: "Total Submissions", value: 156, change: "+12%", icon: FileText, color: "text-blue-600" },
    { label: "Active Reviewers", value: 45, change: "+5%", icon: UserCheck, color: "text-green-600" },
    { label: "Registered Attendees", value: 342, change: "+23%", icon: Users, color: "text-purple-600" },
    { label: "Pending Reviews", value: 28, change: "-8%", icon: Clock, color: "text-orange-600" }
  ];

  const recentSubmissions = [
    {
      id: 1,
      title: "Deep Learning for Medical Image Analysis",
      author: "Dr. Sarah Johnson",
      submittedDate: "2026-02-20",
      status: "Under Review",
      reviewers: 3
    },
    {
      id: 2,
      title: "Blockchain Applications in Supply Chain",
      author: "Prof. Michael Chen",
      submittedDate: "2026-02-19",
      status: "Pending Assignment",
      reviewers: 0
    },
    {
      id: 3,
      title: "AI-Powered Climate Modeling",
      author: "Dr. Emma Wilson",
      submittedDate: "2026-02-18",
      status: "Under Review",
      reviewers: 2
    },
    {
      id: 4,
      title: "Quantum Cryptography Advances",
      author: "Dr. James Rodriguez",
      submittedDate: "2026-02-17",
      status: "Reviewed",
      reviewers: 3
    },
    {
      id: 5,
      title: "Neural Architecture Search Methods",
      author: "Dr. Lisa Anderson",
      submittedDate: "2026-02-16",
      status: "Under Review",
      reviewers: 3
    }
  ];

  const reviewers = [
    {
      id: 1,
      name: "Dr. Robert Brown",
      expertise: "Machine Learning",
      assigned: 8,
      completed: 6,
      pending: 2
    },
    {
      id: 2,
      name: "Prof. Maria Garcia",
      expertise: "Computer Vision",
      assigned: 10,
      completed: 9,
      pending: 1
    },
    {
      id: 3,
      name: "Dr. David Lee",
      expertise: "NLP",
      assigned: 6,
      completed: 4,
      pending: 2
    },
    {
      id: 4,
      name: "Dr. Susan Taylor",
      expertise: "Robotics",
      assigned: 7,
      completed: 7,
      pending: 0
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Under Review": return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "Pending Assignment": return "bg-blue-100 text-blue-700 border-blue-200";
      case "Reviewed": return "bg-green-100 text-green-700 border-green-200";
      default: return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Under Review": return <Clock className="h-3 w-3" />;
      case "Pending Assignment": return <AlertCircle className="h-3 w-3" />;
      case "Reviewed": return <CheckCircle className="h-3 w-3" />;
      default: return <FileText className="h-3 w-3" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background">
      <Navbar 
        isAuthenticated={true}
        userRole="admin"
        userName="Admin User"
        notificationCount={5}
        onNotificationsClick={() => setNotificationsPanelOpen(true)}
      />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage conference operations and monitor submissions</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export Data
            </Button>
            <Button>
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="border-2 hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`h-12 w-12 rounded-xl bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center ${stat.color}`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {stat.change}
                    </Badge>
                  </div>
                  <div className="text-3xl font-bold mb-1">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - Recent Submissions */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-2">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                <div>
                  <CardTitle>Recent Submissions</CardTitle>
                  <CardDescription>Latest paper submissions requiring attention</CardDescription>
                </div>
                <Link to="/reviews">
                  <Button variant="outline" size="sm">
                    View All
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentSubmissions.map((submission) => (
                    <Card key={submission.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <h4 className="font-semibold mb-1">{submission.title}</h4>
                            <p className="text-sm text-muted-foreground">by {submission.author}</p>
                          </div>
                          <Badge className={`${getStatusColor(submission.status)} border flex items-center gap-1`}>
                            {getStatusIcon(submission.status)}
                            {submission.status}
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between text-sm mt-3">
                          <span className="text-muted-foreground">
                            {new Date(submission.submittedDate).toLocaleDateString()}
                          </span>
                          <div className="flex items-center gap-3">
                            <span className="text-muted-foreground">
                              {submission.reviewers}/3 reviewers
                            </span>
                            {submission.status === "Pending Assignment" ? (
                              <Button size="sm" variant="default">
                                Assign Reviewers
                              </Button>
                            ) : (
                              <Button size="sm" variant="ghost">
                                View Details
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Submission Stats Chart */}
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Submission Overview</CardTitle>
                <CardDescription>Distribution of paper statuses</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-yellow-500"></div>
                      <span className="text-sm">Under Review</span>
                    </div>
                    <span className="text-sm font-semibold">65 (42%)</span>
                  </div>
                  <Progress value={42} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-green-500"></div>
                      <span className="text-sm">Accepted</span>
                    </div>
                    <span className="text-sm font-semibold">48 (31%)</span>
                  </div>
                  <Progress value={31} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-blue-500"></div>
                      <span className="text-sm">Pending Assignment</span>
                    </div>
                    <span className="text-sm font-semibold">28 (18%)</span>
                  </div>
                  <Progress value={18} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-red-500"></div>
                      <span className="text-sm">Rejected</span>
                    </div>
                    <span className="text-sm font-semibold">15 (9%)</span>
                  </div>
                  <Progress value={9} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Reviewer Management */}
          <div className="space-y-6">
            {/* Top Reviewers */}
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserCheck className="h-5 w-5" />
                  Active Reviewers
                </CardTitle>
                <CardDescription>Reviewer workload status</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {reviewers.map((reviewer) => (
                  <div key={reviewer.id} className="p-3 rounded-lg border bg-card">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-sm">{reviewer.name}</h4>
                      <Badge variant="outline" className="text-xs">
                        {reviewer.expertise}
                      </Badge>
                    </div>
                    <div className="space-y-1 text-xs text-muted-foreground">
                      <div className="flex justify-between">
                        <span>Assigned:</span>
                        <span className="font-medium">{reviewer.assigned}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Completed:</span>
                        <span className="font-medium text-green-600">{reviewer.completed}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Pending:</span>
                        <span className="font-medium text-orange-600">{reviewer.pending}</span>
                      </div>
                    </div>
                    <Progress 
                      value={(reviewer.completed / reviewer.assigned) * 100} 
                      className="h-1.5 mt-2" 
                    />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link to="/reviews" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="mr-2 h-4 w-4" />
                    Manage Reviews
                  </Button>
                </Link>
                <Link to="/schedule" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    <Calendar className="mr-2 h-4 w-4" />
                    Edit Schedule
                  </Button>
                </Link>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="mr-2 h-4 w-4" />
                  Manage Attendees
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Settings className="mr-2 h-4 w-4" />
                  Conference Settings
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <NotificationPanel 
        isOpen={notificationsPanelOpen}
        onClose={() => setNotificationsPanelOpen(false)}
      />
    </div>
  );
}
