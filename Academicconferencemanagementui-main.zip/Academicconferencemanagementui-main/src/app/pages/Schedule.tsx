import { useState } from "react";
import { Navbar } from "../components/Navbar";
import { NotificationPanel } from "../components/NotificationPanel";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { 
  Calendar,
  Clock,
  MapPin,
  User,
  Users,
  Video,
  Star,
  Bookmark,
  Filter,
  Download,
  Share2
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";

export function Schedule() {
  const [notificationsPanelOpen, setNotificationsPanelOpen] = useState(false);
  const [selectedDay, setSelectedDay] = useState("day1");
  const [bookmarkedSessions, setBookmarkedSessions] = useState<number[]>([1, 3, 7]);

  // Mock data
  const conferenceDays = [
    { id: "day1", label: "Day 1", date: "March 15, 2026", day: "Monday" },
    { id: "day2", label: "Day 2", date: "March 16, 2026", day: "Tuesday" },
    { id: "day3", label: "Day 3", date: "March 17, 2026", day: "Wednesday" },
  ];

  const sessions = {
    day1: [
      {
        id: 1,
        time: "09:00 - 10:30",
        title: "Keynote: The Future of AI in Healthcare",
        speaker: "Dr. Sarah Mitchell",
        speakerTitle: "Chief AI Scientist, MedTech Labs",
        location: "Main Auditorium",
        type: "Keynote",
        attendees: 450,
        isVirtual: false,
        tags: ["AI", "Healthcare", "Keynote"]
      },
      {
        id: 2,
        time: "11:00 - 12:30",
        title: "Machine Learning Fundamentals",
        speaker: "Prof. James Wilson",
        speakerTitle: "Stanford University",
        location: "Room A",
        type: "Workshop",
        attendees: 80,
        isVirtual: true,
        tags: ["Machine Learning", "Workshop"]
      },
      {
        id: 3,
        time: "11:00 - 12:30",
        title: "Computer Vision Applications",
        speaker: "Dr. Maria Garcia",
        speakerTitle: "MIT",
        location: "Room B",
        type: "Technical Session",
        attendees: 120,
        isVirtual: false,
        tags: ["Computer Vision", "Applications"]
      },
      {
        id: 4,
        time: "14:00 - 15:30",
        title: "Natural Language Processing Advances",
        speaker: "Dr. Robert Chen",
        speakerTitle: "Google Research",
        location: "Main Auditorium",
        type: "Technical Session",
        attendees: 200,
        isVirtual: true,
        tags: ["NLP", "Research"]
      },
      {
        id: 5,
        time: "16:00 - 17:30",
        title: "Panel Discussion: Ethics in AI",
        speaker: "Multiple Speakers",
        speakerTitle: "Various Institutions",
        location: "Room A",
        type: "Panel",
        attendees: 150,
        isVirtual: false,
        tags: ["Ethics", "AI", "Panel"]
      }
    ],
    day2: [
      {
        id: 6,
        time: "09:00 - 10:30",
        title: "Quantum Computing: Present and Future",
        speaker: "Dr. Lisa Anderson",
        speakerTitle: "IBM Quantum",
        location: "Main Auditorium",
        type: "Keynote",
        attendees: 420,
        isVirtual: false,
        tags: ["Quantum", "Keynote"]
      },
      {
        id: 7,
        time: "11:00 - 12:30",
        title: "Deep Learning Architectures",
        speaker: "Prof. David Kim",
        speakerTitle: "Oxford University",
        location: "Room A",
        type: "Technical Session",
        attendees: 180,
        isVirtual: true,
        tags: ["Deep Learning", "Architecture"]
      },
      {
        id: 8,
        time: "14:00 - 15:30",
        title: "Reinforcement Learning Workshop",
        speaker: "Dr. Emma Thompson",
        speakerTitle: "DeepMind",
        location: "Room B",
        type: "Workshop",
        attendees: 90,
        isVirtual: false,
        tags: ["Reinforcement Learning", "Workshop"]
      }
    ],
    day3: [
      {
        id: 9,
        time: "09:00 - 10:30",
        title: "AI in Climate Science",
        speaker: "Dr. Michael Brown",
        speakerTitle: "Climate AI Institute",
        location: "Main Auditorium",
        type: "Keynote",
        attendees: 380,
        isVirtual: true,
        tags: ["AI", "Climate", "Keynote"]
      },
      {
        id: 10,
        time: "11:00 - 12:30",
        title: "Best Paper Awards & Closing",
        speaker: "Conference Committee",
        speakerTitle: "Various Institutions",
        location: "Main Auditorium",
        type: "Closing",
        attendees: 500,
        isVirtual: false,
        tags: ["Awards", "Closing"]
      }
    ]
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "Keynote": return "bg-purple-100 text-purple-700 border-purple-200";
      case "Workshop": return "bg-blue-100 text-blue-700 border-blue-200";
      case "Technical Session": return "bg-green-100 text-green-700 border-green-200";
      case "Panel": return "bg-orange-100 text-orange-700 border-orange-200";
      case "Closing": return "bg-red-100 text-red-700 border-red-200";
      default: return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const toggleBookmark = (sessionId: number) => {
    setBookmarkedSessions(prev => 
      prev.includes(sessionId) 
        ? prev.filter(id => id !== sessionId)
        : [...prev, sessionId]
    );
  };

  const isBookmarked = (sessionId: number) => bookmarkedSessions.includes(sessionId);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background">
      <Navbar 
        isAuthenticated={true}
        userRole="user"
        userName="Dr. Jane Smith"
        notificationCount={3}
        onNotificationsClick={() => setNotificationsPanelOpen(true)}
      />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Conference Schedule</h1>
          <p className="text-muted-foreground">Browse sessions, speakers, and plan your conference experience</p>
        </div>

        {/* Conference Info Banner */}
        <Card className="border-2 bg-gradient-to-r from-primary/10 to-accent/10 mb-6">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-lg bg-primary/20 flex items-center justify-center">
                  <Calendar className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Conference Dates</p>
                  <p className="font-semibold">March 15-17, 2026</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-lg bg-primary/20 flex items-center justify-center">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Location</p>
                  <p className="font-semibold">Vienna, Austria</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-lg bg-primary/20 flex items-center justify-center">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Expected Attendees</p>
                  <p className="font-semibold">500+ Researchers</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Filter and Actions */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <Select>
            <SelectTrigger className="md:w-48">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sessions</SelectItem>
              <SelectItem value="keynote">Keynotes</SelectItem>
              <SelectItem value="workshop">Workshops</SelectItem>
              <SelectItem value="technical">Technical Sessions</SelectItem>
              <SelectItem value="panel">Panels</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex gap-2 ml-auto">
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export Schedule
            </Button>
            <Button variant="outline">
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </Button>
          </div>
        </div>

        {/* Schedule Tabs */}
        <Tabs defaultValue="day1" className="w-full">
          <TabsList className="grid grid-cols-3 w-full max-w-2xl mb-6">
            {conferenceDays.map((day) => (
              <TabsTrigger key={day.id} value={day.id}>
                <div className="text-center">
                  <div className="font-semibold">{day.label}</div>
                  <div className="text-xs text-muted-foreground">{day.day}</div>
                </div>
              </TabsTrigger>
            ))}
          </TabsList>

          {conferenceDays.map((day) => (
            <TabsContent key={day.id} value={day.id} className="space-y-4">
              {/* Day Header */}
              <Card className="border-2 bg-secondary/50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{day.date}</h3>
                      <p className="text-sm text-muted-foreground">{sessions[day.id as keyof typeof sessions].length} sessions scheduled</p>
                    </div>
                    <Badge variant="outline">
                      {bookmarkedSessions.filter(id => 
                        sessions[day.id as keyof typeof sessions].some(s => s.id === id)
                      ).length} Bookmarked
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Sessions */}
              <div className="space-y-4">
                {sessions[day.id as keyof typeof sessions].map((session) => (
                  <Card key={session.id} className="border-2 hover:shadow-lg transition-all">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        {/* Time Column */}
                        <div className="flex-shrink-0 text-center w-24">
                          <div className="h-16 w-16 rounded-lg bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center mb-2 mx-auto">
                            <Clock className="h-6 w-6 text-primary" />
                          </div>
                          <p className="text-sm font-semibold">{session.time}</p>
                        </div>

                        {/* Main Content */}
                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <h3 className="text-lg font-semibold">{session.title}</h3>
                                {session.isVirtual && (
                                  <Badge variant="outline" className="bg-blue-50">
                                    <Video className="h-3 w-3 mr-1" />
                                    Virtual
                                  </Badge>
                                )}
                              </div>
                              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                                <User className="h-4 w-4" />
                                <span className="font-medium">{session.speaker}</span>
                                <span>•</span>
                                <span>{session.speakerTitle}</span>
                              </div>
                              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-4 w-4" />
                                  {session.location}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Users className="h-4 w-4" />
                                  {session.attendees} attending
                                </span>
                              </div>
                              <div className="flex flex-wrap gap-2">
                                <Badge className={`${getTypeColor(session.type)} border`}>
                                  {session.type}
                                </Badge>
                                {session.tags.map((tag, idx) => (
                                  <Badge key={idx} variant="outline" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* Actions */}
                          <div className="flex gap-2 pt-3 border-t">
                            <Button
                              variant={isBookmarked(session.id) ? "default" : "outline"}
                              size="sm"
                              onClick={() => toggleBookmark(session.id)}
                            >
                              <Bookmark className={`mr-2 h-4 w-4 ${isBookmarked(session.id) ? 'fill-current' : ''}`} />
                              {isBookmarked(session.id) ? 'Bookmarked' : 'Bookmark'}
                            </Button>
                            <Button variant="outline" size="sm">
                              View Details
                            </Button>
                            {session.isVirtual && (
                              <Button size="sm" className="ml-auto">
                                <Video className="mr-2 h-4 w-4" />
                                Join Virtual
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {/* My Schedule Summary */}
        {bookmarkedSessions.length > 0 && (
          <Card className="border-2 mt-6 bg-gradient-to-r from-accent/10 to-primary/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-primary" />
                My Schedule
              </CardTitle>
              <CardDescription>
                You have {bookmarkedSessions.length} sessions bookmarked
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Button variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Export My Schedule
                </Button>
                <Button variant="outline">
                  <Calendar className="mr-2 h-4 w-4" />
                  Add to Calendar
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <NotificationPanel 
        isOpen={notificationsPanelOpen}
        onClose={() => setNotificationsPanelOpen(false)}
      />
    </div>
  );
}
